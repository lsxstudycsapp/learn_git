import matplotlib.pyplot as plt
import time

'''
7. 有以下数据：
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 
    484., 489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
     14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
   请训练一个线性回归模型，要求训练集的r2_score在0.999以上。提交的内容包括：模型参数，训练集的r2_score，以及模型训练的时间(毫秒)。
   可选语言：Python或者c++。
   如果用Python语言，不能使用numpy和pandas，不能使用sklearn。如果用c++，只能用原生的c++语言，不能调用任何矩阵运算库和机器学习库。
'''

x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
     14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

# 归一化
x_min, x_max = min(x), max(x)
y_min, y_max = min(y), max(y)
x = list((x[i] - x_min) / (x_max - x_min) for i in range(len(x)))
# print(x)
y = list((y[i] - y_min) / (y_max - y_min) for i in range(len(y)))
# print(y)

# 曲线分布 ax^2 + bx + c = 0, y = theta0 + theta1 * x_1 + theta2 * x_2
# plt.scatter(x, y)
# plt.show()

# 添加截距和特征拓展
x_matrix = []
for i in range(len(x)):
    x_matrix.append([1.0, x[i], x[i] ** 2])
# print(x_matrix)

# 矩阵转置
x_matrix_T = []
for i in range(3):
    list_temp = []
    for j in range(len(x_matrix)):
        list_temp.append(x_matrix[j][i])
    x_matrix_T.append(list_temp)
# print(x_matrix_T)

# 梯度下降斜率初始化
theta = [[0.0],
         [0.0],
         [0.0]]


# 预测值计算
def y_hat_func(matrix_a, matrix_b):
    matrix_temp = []
    for i in range(len(matrix_a)):
        sum_temp = 0
        for k in range(len(matrix_b)):
            sum_temp += matrix_a[i][k] * matrix_b[k][0]
        matrix_temp.append([sum_temp])
    return matrix_temp


# 求导计算
def derivation_func(matrix_a, y_hat_arg, y_arg):
    temp = []
    for i in range(len(y_hat_arg)):
        temp.append([y_hat_arg[i][0] - y_arg[i]])
    matrix_temp = []
    for i in range(len(matrix_a)):
        sum_temp = 0
        for k in range(len(temp)):
            sum_temp += matrix_a[i][k] * temp[k][0]
        matrix_temp.append([sum_temp])
    return matrix_temp


# 模型训练
def gradientdescent_bgd(alpha_arg, iters_arg):
    m = len(y)
    costs = []
    for i in range(iters_arg):
        y_hat = y_hat_func(x_matrix, theta)
        derivation = derivation_func(x_matrix_T, y_hat, y)
        for k in range(len(theta)):
            theta[k][0] -= alpha_arg * (1.0 / m) * derivation[k][0]
        c = cost()
        costs.append(c)
        # break
    return costs


# 损失值计算
def cost():
    m = len(y)
    y_hat = y_hat_func(x_matrix, theta)
    sum_square = 0
    for i in range(len(y_hat)):
        sum_square += (y_hat[i][0] - y[i]) ** 2
    func_j = 1.0 / (2 * m) * sum_square
    return func_j


if __name__ == '__main__':
    start_time = time.time()
    alpha = 0.1
    iters = 20000
    result = gradientdescent_bgd(alpha, iters)
    # print(theta)
    # print(result)
    # print(len(result) - 1)
    # plt.plot(range(len(result) - 1), result[1:])
    # plt.show()

    predict_y = y_hat_func(x_matrix, theta)
    # print(predict_y)
    y_aver = sum(y) / len(y)
    # print(y_aver)
    rss = 0
    tss = 0
    for i in range(len(y)):
        rss += (y[i] - predict_y[i][0]) ** 2
        tss += (y[i] - y_aver) ** 2
    r2 = 1 - rss / tss
    # print(rss)
    # print(tss)
    # print(r2)
    train_time = (time.time() - start_time) * 1000
    print(f"步长因子alpha: {alpha}")
    print(f"循环批次iters: {iters}")
    print(f"模型性能评估r2_score: {r2}")
    print(f"模型训练时间ms: {train_time:.2f} ms")
