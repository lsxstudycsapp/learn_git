import math
import matplotlib.pyplot as plt

x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
     14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]


def min_max(x):
    max_v = max(x)
    min_v = min(x)
    for i in range(m):
        x[i] = (x[i] - min_v) / (max_v - min_v)
    return x


m = len(x)
x0 = [1] * m
x1 = min_max(x)
x2 = [num ** 2 for num in x]
y = min_max(y)
theta = [0, 0, 0]


def y_pre(theta):
    y_hat = []
    for i in range(m):
        y_ = theta[0] * x0[i] + theta[1] * x1[i] + theta[2] * x2[i]
        y_hat.append(y_)
    return y_hat


def loss(theta):
    y_hat = y_pre(theta)
    mse = 0
    for i in range(m):
        mse += (y[i] - y_hat[i]) ** 2
    loss = 1.0 / (2 * m) * mse
    return loss


def r2_score(theta):
    y_mean = sum(y) / m
    mse = 0
    var = 0
    y_hat = y_pre(theta)
    for i in range(m):
        mse += (y[i] - y_hat[i]) ** 2
        var += (y[i] - y_mean) ** 2
    r2_score = 1 - (mse / var)
    return r2_score


def gradientDescent_bgd(x0, x1, x2, y, theta, alpha=0.01, iters=1500):
    m = len(y)
    costs = []
    for _ in range(iters):
        y_hat = y_pre(theta)
        t0 = t1 = t2 = 0
        for i in range(m):
            t0 += x0[i] * (y_hat[i] - y[i])
            t1 += x[i] * (y_hat[i] - y[i])
            t2 += x2[i] * (y_hat[i] - y[i])
        theta[0] -= alpha * (1.0 / m) * t0
        theta[1] -= alpha * (1.0 / m) * t1
        theta[2] -= alpha * (1.0 / m) * t2
        c = loss(theta)
        costs.append(c)
        r2 = r2_score(theta)
    return costs, r2

import time

if __name__ == '__main__':
    T1 = time.time()
    bgd = gradientDescent_bgd(x0, x1, x2, y, theta=theta, alpha=0.003, iters=500000)
    T2 = time.time()
    print('程序运行时间:%s毫秒' % ((T2 - T1) * 1000))
    print(theta)
    print(r2_score(theta))
