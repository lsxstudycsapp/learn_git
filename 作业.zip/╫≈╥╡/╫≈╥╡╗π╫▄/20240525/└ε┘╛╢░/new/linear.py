class MaxMin:

    def __init__(self):
        self.mx = 0
        self.mn = 0

    def fit(self,xs):
        for x in xs:
            self.mx = max(x,self.mx)
            self.mn = min(x,self.mn)

    def transform(self,xs):
        return [(x-self.mn)/(self.mx-self.mn) for x in xs]

    def inverse(self,xs):
        return [self.mn+x*(self.mx-self.mn) for x in xs]

class Linear:

    def __init__(self,pw):
        self.pw = pw
        self.theta = [0.]*(pw+1)
        self.cache = {}

    def polyx(self,x):
        if x in self.cache:
            return self.cache[x]
        res = [1]
        for p in range(1,self.pw+1):
            res.append(x**p)
        self.cache[x]=res[:]
        return self.cache[x]

    def get_predy(self,x):
        px = self.polyx(x)
        y = self.theta[0]
        for p in range(1,self.pw+1):
            y += px[p]*self.theta[p]
        return y

    def train(self,xs,ys,alpha,max_epo):

        for epo in range(max_epo):
            gradient = [0.]*(self.pw+1)
            for x,y in zip(xs,ys):
                px = self.polyx(x)
                ypred = self.get_predy(x)
                for p in range(self.pw+1):
                    gradient[p] += px[p]*(ypred-y)
            for p in range(self.pw+1):
                self.theta[p] -= gradient[p]*alpha/len(ys)
            if epo and epo%10000 == 0:
                print(" Training... epo {}".format(epo))

    def getr2(self,ypreds,ys):

        yavg = sum(ys)/len(ys)
        rss = 0
        tss = 0
        for j in range(len(ys)):
            rss += (ypreds[j]-ys[j])*(ypreds[j]-ys[j])
            tss += (ypreds[j]-yavg)*(ypreds[j]-yavg)
        return 1-rss/tss

if __name__ == "__main__":

    mdl = Linear(2,True)
    x = 2
    print(mdl.polyx(x))