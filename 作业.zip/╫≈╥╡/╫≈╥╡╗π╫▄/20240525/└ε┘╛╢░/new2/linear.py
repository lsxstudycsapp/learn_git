def reverse(mat):
    m,n = len(mat),len(mat[0])
    return  [[mat[j][i] for j in range(m)] for i in range(n)]

def matmul(a,b):
    ma,na = len(a),len(a[0])
    mb,nb = len(b),len(b[0])
    if na!=mb:
        return []
    return [[sum(a[ra][ca]*b[ca][cb] for ca in range(na)) for cb in range(nb)] for ra in range(ma)]

def conf(mat,i,j):
    return [row[:j] + row[j+1:] for row in (mat[:i] + mat[i+1:])]

def det(mat):
    return sum(((-1)**c)*mat[0][c]*det(conf(mat,0,c)) for c in range(len(mat))) if len(mat)>1 else mat[0][0]

def astar(mat):
    n = len(mat)
    return [[((-1)**(i+j))*det(conf(mat, j, i)) for j in range(n)] for i in range(n)]

def inverse(mat):
    n = len(mat)
    dt = det(mat)
    if not dt:
        return []
    star = astar(mat)
    return [[star[i][j]/dt for j in range(n)] for i in range(n)]

class MaxMin:

    def __init__(self):
        self.mx = 0
        self.mn = 0

    def fit(self,xs):
        for x in xs:
            self.mx = max(x,self.mx)
            self.mn = min(x,self.mn)

    def transform(self,xs):
        return [(x-self.mn)/(self.mx-self.mn) for x in xs]

    def inverse(self,xs):
        return [self.mn+x*(self.mx-self.mn) for x in xs]

class Linear:

    def __init__(self,pw):
        self.pw = pw
        self.theta = [0.]*(pw+1)
        self.cache = {}

    def polyx(self,x):
        if x in self.cache:
            return self.cache[x]
        res = [1]
        for p in range(1,self.pw+1):
            res.append(x**p)
        self.cache[x]=res[:]
        return self.cache[x]

    def get_predy(self,x):
        px = self.polyx(x)
        y = self.theta[0]
        for p in range(1,self.pw+1):
            y += px[p]*self.theta[p]
        return y

    def train(self,xs,ys,alpha,max_epo):

        for epo in range(max_epo):
            gradient = [0.]*(self.pw+1)
            for x,y in zip(xs,ys):
                px = self.polyx(x)
                ypred = self.get_predy(x)
                for p in range(self.pw+1):
                    gradient[p] += px[p]*(ypred-y)
            for p in range(self.pw+1):
                self.theta[p] -= gradient[p]*alpha/len(ys)
            if epo and epo%10000 == 0:
                print(" Training... epo {}".format(epo))

    def get_solved(self,xs,ys):
        xs = [self.polyx(x) for x in xs]
        ys = [[y] for y in ys]
        theta = matmul(matmul(inverse(matmul(reverse(xs),xs)),reverse(xs)),ys)
        for j in range(len(self.theta)):
            self.theta[j]=theta[j][0]
    def getr2(self,ypreds,ys):

        yavg = sum(ys)/len(ys)
        rss = 0
        tss = 0
        for j in range(len(ys)):
            rss += (ypreds[j]-ys[j])*(ypreds[j]-ys[j])
            tss += (ypreds[j]-yavg)*(ypreds[j]-yavg)
        return 1-rss/tss

if __name__ == "__main__":

    mdl = Linear(2,True)
    x = 2
    print(mdl.polyx(x))