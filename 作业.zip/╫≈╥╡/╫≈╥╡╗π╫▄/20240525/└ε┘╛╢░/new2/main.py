import time
import matplotlib.pyplot as plt
from linear import Linear,MaxMin

if __name__=="__main__":

    xs = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    ys = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

    mdl = Linear(2)

    scalerx = MaxMin()
    scalery = MaxMin()
    scalerx.fit(xs)
    scalery.fit(ys)
    xs1 = scalerx.transform(xs)
    ys1 = scalery.transform(ys)

    # tme1 = time.time()
    # mdl.train(xs1,ys1,alpha=.8,max_epo=75000)
    # tme2 = time.time()
    # tme = int((tme2-tme1)*1000)

    tme1 = time.time_ns()
    mdl.get_solved(xs1,ys1)
    tme2 = time.time_ns()
    tme = float((tme2-tme1)/1000)

    y_pred = []
    for x in xs1:
        y_pred.append(mdl.get_predy(x))
    y_pred = scalery.inverse(y_pred)

    r2 = mdl.getr2(y_pred,ys)
    print("r2 score is {}".format(r2))
    fp = open("result.txt",'w')
    fp.write("Training time {} ms\n theta is {}\n r2score is {}\n".format(tme,mdl.theta,r2))
    fp.close()

    plt.clf()
    plt.scatter(xs,ys,c='r')
    plt.plot(xs,y_pred,c='b')
    plt.savefig("result.png")