import time
x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
     14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
m = 1
b = 1

rx = [i / 1000 for i in x]
# print(rx)

ry = [i / 1000 for i in y]
# print(ry)
# m = 38
# b = 1.6
def gfunc(a, c, m, b, ar=0.0001):
    loss, mpd, bpd = 0, 0, 0
    for xi, yi in zip(rx, ry):
        # print(f"xi = {xi} , yi = {yi}")
        loss = loss + (m * xi + b - yi)**2
        mpd = mpd + (m * xi + b - yi)*2*xi
        bpd = bpd + (m * xi + b - yi)*2
        # print(f"loss = {loss}, m = {m}, b = {b}")

    N = len(x)
    # print(f"N = {N}")
    loss = loss / N
    mpd = mpd / N
    bpd = bpd / N
    m = m - mpd*ar
    # print(f"m = {m}")
    b = b - bpd*ar
    # print(f"b = {b}")
    return loss, m, b


star_time = time.time()
mse = 0
for i in range(2000000):
    mse, m, b = gfunc(rx, ry, m, b)
    if i % 5000000 == 0:
        print(f"mse = {mse} ,m = {m}, b = {b}")
print(f" out mse = {mse} ,m = {m}, b = {b}")


def ssr(yi, x1):
    # m = 142.84685144630117
    # b = -45.220112571370905
    # mse = 152.87018373795908
    sum7 = 0
    for y1, y2 in zip(yi, x1):
        p = (y1 - (m * y2 + b)) ** 2
        sum7 += p
        # print(sum7)
    return sum7


def yaver(y1):
    a_sum = 0
    for i in y1:
        a_sum += i
    n3 = len(y1)
    a_sum = a_sum/n3
    return a_sum


def sst(y3, y4):
    count = 0
    sum2 = 0
    for i in y3:
        y6 = (i-y4)**2
        # print("y6 = ", y6)
        sum2 += y6
        count += 1
        # print("count = ", count)
        # print("sum2 = ", sum2)
    return sum2


ssr1 = ssr(ry, rx)
y_ = yaver(ry)
sst1 = sst(ry, y_)
print("sst= ", sst1)
print("ssr=", ssr1)

r2 = ssr1/sst1

print("r2 = ", r2)
end_time = time.time()
print("pay time :", end_time-star_time, " s")



