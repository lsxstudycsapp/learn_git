import matplotlib.pyplot as plt
import time


# MinMax 归一化
def min_max_normalized(x, y):
    x_nor = []
    y_nor = []

    x_min = min(x)
    x_max = max(x)
    y_min = min(y)
    y_max = max(y)
    for i in range(len(x)):
        xi = (x[i] - x_min) / (x_max - x_min)
        yi = (y[i] - y_min) / (y_max - y_min)
        x_nor.append(xi)
        y_nor.append(yi)
    return x_nor, y_nor


#  批量梯度下降
def gradientDescent_bgd(X, Y, alpha, iters):
    theta0 = theta1 = theta2 = 0.
    m = len(X)
    theta = []

    for _ in range(iters):

        grad_theta0 = grad_theta1 = grad_theta2 = 0
        for i in range(len(X)):
            # 计算梯度
            grad_theta0 += (1.0 / m) * ((theta0 + theta1 * X[i] + theta2 * X[i] ** 2) - Y[i])
            grad_theta1 += (1.0 / m) * X[i] * ((theta0 + theta1 * X[i] + theta2 * X[i] ** 2) - Y[i])
            grad_theta2 += (1.0 / m) * X[i] ** 2 * ((theta0 + theta1 * X[i] + theta2 * X[i] ** 2) - Y[i])

        # 更新参数
        theta0 -= alpha * grad_theta0
        theta1 -= alpha * grad_theta1
        theta2 -= alpha * grad_theta2
    theta.extend([theta0, theta1, theta2])
    return theta


def predict(X_train, theta):
    y_pred = []
    for i in range(len(X_train)):
        y_i = theta[0] + theta[1] * X_train[i] + theta[2] * X_train[i] ** 2
        y_pred.append(y_i)
    return y_pred


# 计算R_2分数
def R2_score(Y, Y_pred):
    rss = sum((Y[i] - Y_pred[i]) ** 2 for i in range(len(Y)))
    tss = sum((Y[i] - sum(Y) / len(Y)) ** 2 for i in range(len(Y)))
    r2_score = 1 - (rss / tss)
    return r2_score


if __name__ == '__main__':
    # 数据集
    X = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478.,
         484., 489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    Y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
         14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

    # 训练开始时间
    start_time = time.time() * 1000

    x_nor, y_nor = min_max_normalized(X, Y)
    theta = gradientDescent_bgd(x_nor, y_nor, alpha=1.0, iters=8000)
    y_pred = predict(x_nor, theta)
    # 训练结束时间
    end_time = time.time() * 1000

    # 参数展示
    print(f'theta: {theta}')
    print(f'r_2score: {R2_score(y_nor, y_pred)}')
    print(f'模型训练的需要的时间: {end_time - start_time}毫秒')

    # plt.scatter(x_nor, y_nor)
    # plt.scatter(x_nor, y_pred, c='green')
    # plt.show()
