#include <iostream>
#include <vector>
#include <cmath>
#include <chrono>
#include <utility>
double Mean(const std::vector<double>& data) {
    double sum = 0.0;
    for (double val : data) {
        sum += val;
    }
    return sum / data.size();
}
double Variance(const std::vector<double>& data, double mean) {
    double sum = 0.0;
    for (double val : data) {
        sum += std::pow(val - mean, 2);
    }
    return sum / (data.size() - 1);
}
double Covariance(const std::vector<double>& x, const std::vector<double>& y, double xMean, double yMean) {
    double sum = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        sum += (x[i] - xMean) * (y[i] - yMean);
    }
    return sum / (x.size() - 1);
}
std::pair<double, double> LinearRegressionParameters(const std::vector<double>& x, const std::vector<double>& y) {
    double xMean = Mean(x);
    double yMean = Mean(y);

    double xxVariance = Variance(x, xMean);
    double xyCovariance = Covariance(x, y, xMean, yMean);

    double a = xyCovariance / xxVariance;
    double b = yMean - a * xMean;

    return {a, b};
}
double calculateR2Score(const std::vector<double>& y, const std::vector<double>& yPred, double yMean) {
    double ss_res = 0.0; // Residual sum of squares
    double ss_tot = 0.0; // Total sum of squares

    for (size_t i = 0; i < y.size(); ++i) {
        ss_res += std::pow(y[i] - yPred[i], 2);
        ss_tot += std::pow(y[i] - yMean, 2);
    }

    return 1 - (ss_res / ss_tot);
}
int main() {
    std::vector<double> x = {290, 329, 342, 359, 369, 386, 395, 410, 425, 427, 433,
                             437, 445, 450, 458, 462, 469, 478, 484,
                             489, 495, 496, 502, 509, 511, 514, 516, 518, 521, 523};
    std::vector<double> y = {36302, 15125, 10094, 5045, 2885, 590, 77, 302, 1877, 2189,
                             3269, 4109, 6077, 7502, 10094, 11534, 14285, 18254,21170,
                             23765, 27077, 27650, 31214, 35645, 36965, 38990, 40370, 41774,
                             43925, 45389};
    auto start = std::chrono::high_resolution_clock::now();
    std::pair<double, double> regressionParams = LinearRegressionParameters(x, y); // 使用std::pair接收参数
    double a = regressionParams.first;  // 斜率
    double b = regressionParams.second;  // 截距

    std::vector<double> yPred(y.size());
    for (size_t i = 0; i < x.size(); ++i)
    {
        yPred[i] = a * x[i] + b;
    }
    double yMean = Mean(y);
    double r2Score = calculateR2Score(y, yPred, yMean);
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    std::cout << "Model parameters: a = " << a << ", b = " << b << std::endl;
    std::cout << "R2 Score: " << r2Score << std::endl;
    std::cout << "Training time (ms): " << duration << std::endl;

    return 0;
}

