import time
# 数据
# x = [290, 329, 342, 359, 369, 386, 395, 410, 425, 427, 433,
#      437, 445, 450, 458, 462, 469, 478, 484,
#      489, 495, 496, 502, 509, 511, 514, 516, 518, 521, 523]
x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
# y = [36302, 15125, 10094, 5045, 2885, 590, 77, 302, 1877, 2189,
#      3269, 4109, 6077, 7502, 10094, 11534, 14285, 18254]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
# 数据集均值
def mean(data):
    return sum(data) / len(data)

# 协方差
def covariance(x, y):
    mean_x = mean(x)
    mean_y = mean(y)
    cov = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))  # 协方差
    return cov / (len(x) - 1)  # 样本协方差 /（n-1）

# 方差
def variance(data):
    mean_data = mean(data)
    var = sum((xi - mean_data) ** 2 for xi in data)  # 方差
    return var / (len(data) - 1)  # 样本方差

# 系数
def correlation(x, y):
    return covariance(x, y) / (variance(x) * variance(y)) ** 0.5

# 回归系数
def regression_coefficients(x, y):
    b1 = covariance(x, y) / variance(x)  # 斜率b1
    b0 = mean(y) - b1 * mean(x)   # 截距b0
    return b0, b1

# 预测值
def predict(x, b0, b1):
    return [b0 + b1 * xi for xi in x]   # 计算x的预测值y

# r2_score
def r2_score(y, y_pred):
    y_mean = mean(y)
    ss_tot = sum((yi - y_mean) ** 2 for yi in y)  # 总平方和
    ss_res = sum((yi - fi) ** 2 for yi, fi in zip(y, y_pred))  # 残差平方和
    return 1 - (ss_res / ss_tot)

# 训练
start_time = time.time()  # 开始时间
b0, b1 = regression_coefficients(x, y)   # 回归系数
y_pred = predict(x, b0, b1)  # 预测值
r2 = r2_score(y, y_pred)     # r2分数
end_time = time.time()       # 结束时间

print("模型参数：b0 = {:.2f}, b1 = {:.2f}".format(b0, b1))
print("r2_score：{:.4f}".format(r2))
print("模型训练的时间（毫秒）：{:.2f}".format((end_time - start_time) * 1000))
