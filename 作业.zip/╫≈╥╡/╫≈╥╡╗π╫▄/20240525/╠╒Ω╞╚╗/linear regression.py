import matplotlib.pyplot as plt

class linear1:#只能处理一个x和y
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.j = 0.0
        self.k = 0.0
    def train(self):
# print((X.T * X).I*X.T)
        a = len(self.x)
        b = c = sum(self.x)
        d = sum(i**2 for i in self.x)
        m = a*d-b*c
        if(m != 0):
            a1 = d/m
            b1 = -b/m
            c1 = -c/m
            d1 = a/m
        else:
            print("矩阵不可逆")

        j = []
        k = []
        for i in x:
            j.append(a1+b1*i)
            k.append(c1+d1*i)

        self.j = sum(map(lambda i, o: i * o, j, self.y))
        self.k = sum(map(lambda i, o: i * o, k, self.y))

    def predict(self, X):
        x = []
        for i in X:
            y = self.j + i * self.k
            x.append(y)
        return x

    def r2(self):
        y_predic = []
        for i in self.x:
            y_predic.append(self.j + i * self.k)
        y_mean = sum(self.y)/len(self.y)
        y_var_mean = sum((i-y_mean)**2 for i in self.y )
        y_var_line = sum((i-y_mean)**2 for i in y_predic )
        r2 = y_var_line/y_var_mean
        return r2

    def mse(self):
        y_predic = []
        for i in self.x:
            y_predic.append(self.j + i * self.k)
        mse = sum(map(lambda i, o: (i-o)**2, self.y, y_predic))
        return mse

    def show(self):
        y_predic = []
        for i in self.x:
            y_predic.append(self.j + i * self.k)
        plt.plot(self.x, self.y, 'bo', label=u'真实值')
        plt.plot(self.x, y_predic, 'r--o', label=u'预测值')
        plt.legend(loc='lower right')
        plt.show()
class linear2:#处理两个x, x**2 和 y
    def __init__(self, x, y):
        self.x1 = x
        self.x2 = [i**2 for i in x]
        self.y = y
        self.j = 5
        self.k = 6
        self.l = 7
        self.y_pre = []

    def train(self):
        # print((X.T * X).I*X.T)
        a11 = len(self.x1)
        a12 = a21 = sum(self.x1)
        a13 = a31 = sum(self.x2)
        a22 = sum(i ** 2 for i in self.x1)
        a23 = a32 = sum(map(lambda i, o: i * o, self.x1, self.x2))
        a33 = sum(i ** 2 for i in self.x2)
        D = a11*a22*a33 + a12*a23*a31 + a13*a21*a32 - a13*a22*a31 - a12*a21*a33 - a11*a23*a32
        if (D != 0):
            b11 = (a22*a33 - a32*a23) / D
            b12 = (a32*a13 - a12*a33) / D
            b13 = (a12*a23 - a22*a13) / D
            b21 = (a23*a31 - a33*a21) / D
            b22 = (a33*a11 - a13*a31) / D
            b23 = (a13*a21 - a23*a11) / D
            b31 = (a21*a32 - a31*a22) / D
            b32 = (a31*a12 - a11*a32) / D
            b33 = (a11*a22 - a21*a12) / D
        else:
            print("矩阵不可逆")

        j = []
        k = []
        l = []
        for i, o in zip(self.x1, self.x2):
            j.append(b11 + b12 * i + b13 * o)
        for i, o in zip(self.x1, self.x2):
            k.append(b21 + b22 * i + b23 * o)
        for i, o in zip(self.x1, self.x2):
            l.append(b31 + b32 * i + b33 * o)


        self.j = sum(map(lambda i, o: i * o, j, self.y))
        self.k = sum(map(lambda i, o: i * o, k, self.y))
        self.l = sum(map(lambda i, o: i * o, l, self.y))

        for i, o in zip(self.x1, self.x2):
            self.y_pre.append(self.j + i * self.k + o * self.l)

    def predict(self, X):
        X1 = X
        X2 = X**2
        for i, o in X1, X2:
            y = self.j + i * self.k + o * self.l
            x.append(y)
        return x
    def r2(self):

        y_mean = sum(self.y) / len(self.y)
        y_var_mean = sum((i - y_mean) ** 2 for i in self.y)
        y_var_line = sum((i - y_mean) ** 2 for i in self.y_pre)
        r2 = y_var_line / y_var_mean
        return r2

    def mse(self):

        mse = sum(map(lambda i, o: (i - o) ** 2, self.y, self.y_pre))
        return mse

    def show(self):

        plt.plot(self.x1, self.y, 'bo', label=u'真实值')
        plt.plot(self.x1, self.y_pre, 'r--o', label=u'预测值')
        plt.legend(loc='lower right')
        plt.show()

if __name__ == '__main__':
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
    s1 = linear2(x, y)
    s1.train()
    # print(s1.predict([550]))
    r2 = s1.r2()
    print(f"r2 = {r2}")  # r2 = 1.0000000000215483
    mse = s1.mse()
    print(f"mse = {mse}")  # mse = 4.950590224796268e-12
    # s1.show()


