import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

mpl.rcParams['font.sans-serif'] = [u'simHei']
mpl.rcParams['axes.unicode_minus'] = False

X1 = np.array([10, 15, 20, 30, 50, 60, 60, 70]).reshape((-1, 1))
Y = np.array([0.8, 1.0, 1.8, 2.0, 3.2, 3.0, 3.1, 3.5]).reshape((-1, 1))
X = np.column_stack((np.ones((X1.shape[0], 1)), X1))

theta = np.dot(np.dot(np.linalg.inv(np.dot(X.T, X)), X.T), Y)
print(theta)
predict_y = np.dot(X, theta)
print(predict_y)

mse = mean_squared_error(Y, predict_y)
print('mse: ', mse)

mae = mean_absolute_error(Y, predict_y)
print('mae: ', mae)

r2_score = r2_score(Y, predict_y)
print('r2_score: ', r2_score)


x_test = np.array([[1, 55]])
y_test_pred = np.dot(x_test, theta)
print(y_test_pred)


plt.plot(X1, Y, 'bo', label=u'真实值')
plt.plot(X1, predict_y, 'r--o', label=u'预测值')
plt.legend(loc='lower right')
plt.show()
