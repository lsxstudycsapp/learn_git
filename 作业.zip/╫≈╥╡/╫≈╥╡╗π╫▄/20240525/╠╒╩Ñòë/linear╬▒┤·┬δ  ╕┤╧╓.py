import numpy as np


class Linear:
    def __init__(self, intercept=True):
        self.intercept = intercept
        self.theta_0 = 0
        self.theta = None

    def train(self, x, y):
        if self.intercept:
            x = np.column_stack((np.ones((x.shape[0], 1)), x))

        theta = np.dot(np.dot(np.linalg.inv(np.dot(x.T, x)), x.T), y)
        print(theta)
        if self.intercept:
            self.theta_0 = theta[0]
            self.theta = theta[1:]
        else:
            self.theta = theta

    def predict(self, x):
        return x * self.theta + self.theta_0

    def score(self):
        pass

    def save(self):
        pass

    def load(self):
        pass


if __name__ == "__main__":
    x_train = np.array([10, 15, 20, 3, 50, 60, 60, 70]).reshape((-1, 1))
    y_train = np.array([0.8, 1.0, 1.8, 2.0, 3.2, 3.0, 3.1, 30.5]).reshape((-1, 1))
    linear_model = Linear()
    linear_model.train(x_train, y_train)

    y_test = [[55,23]]
    y_hat = linear_model.predict(y_test)
    print(y_hat)
    print(linear_model.theta)
    print(linear_model.theta_0)

