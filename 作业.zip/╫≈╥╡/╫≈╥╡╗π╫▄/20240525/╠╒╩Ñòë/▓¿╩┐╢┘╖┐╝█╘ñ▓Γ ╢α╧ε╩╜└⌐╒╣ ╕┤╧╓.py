import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Lasso, LassoCV, Ridge, RidgeCV, ElasticNet
from sklearn.preprocessing import PolynomialFeatures

import warnings

warnings.filterwarnings("ignore")

data = pd.read_csv('../data/boston_housing.data', sep='\s+', header=None)

print(data.head())

X = data.iloc[:, :-1]
Y = data.iloc[:, -1]
print(X)
print(Y)

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.33, random_state=10)

poly = PolynomialFeatures(degree=3, interaction_only=False, include_bias=False)
x_train_poly = poly.fit_transform(x_train)
x_test_poly = poly.transform(x_test)

# lin_model = LinearRegression()
# lin_model.fit(x_train_poly, y_train)
# print("多项式扩展训练集效果：", lin_model.score(x_train_poly, y_train))
# print("多项式扩展测试集效果：", lin_model.score(x_test_poly, y_test))

#
# Ridge_m = RidgeCV([0.01, 0.1, 1.0, 10, 100, 1000, 10000, 100000, 1000000, 10000000], cv=10)
# Ridge_m.fit(x_train_poly, y_train)
# print("多项式扩展训练集效果：", Ridge_m.score(x_train_poly, y_train))
# print("多项式扩展测试集效果：", Ridge_m.score(x_test_poly, y_test))


lass_m = LassoCV(alphas=[0.01, 0.1, 1.0, 10, 100, 1000, 10000, 100000, 1000000, 10000000], cv=10)
lass_m.fit(x_train_poly, y_train)
print("多项式扩展训练集效果：", lass_m.score(x_train_poly, y_train))
print("多项式扩展测试集效果：", lass_m.score(x_test_poly, y_test))
print(lass_m.alpha_)

