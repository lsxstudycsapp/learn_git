import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

data = pd.read_csv('../data/boston_housing.data', sep='\s+', header=None)

print(data.head())

X = data.iloc[:, :-1]
Y = data.iloc[:, -1]
print(X)
print(Y)


x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.33, random_state=10)

lin_model = LinearRegression()
lin_model.fit(x_train, y_train)

y_test_pred = lin_model.predict(x_test)
print("y_test_pred: ", y_test_pred)
print("y_test: ", y_test)
print("训练集效果：",lin_model.score(x_train, y_train))
print("测试集效果：",lin_model.score(x_test, y_test))

