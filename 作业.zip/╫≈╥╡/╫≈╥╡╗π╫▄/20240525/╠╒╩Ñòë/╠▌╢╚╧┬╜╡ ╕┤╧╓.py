import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score


np.set_printoptions(suppress=True)

class Linear:
    def __init__(self, intercept=True):
        self.intercept = intercept
        self.theta_0 = 0
        self.theta = None
        self.costs = []

    def train(self, x, y):
        pass

    def predict(self):
        pass

    def gradientDescent_bgd(self, x, y, alpha, epoch):
        self.theta = np.zeros((x.shape[1], 1))
        for i in range(epoch):
            y_hat = x.dot(self.theta)
            # print(f"第{i}轮的y_hat: ", y_hat)
            self.theta -= alpha * (1/y.size) * (np.dot(x.T, (y_hat - y)))
            # print(f"第{i}轮的theta: ", self.theta)
            c = self.cost(x, y)
            self.costs.append(c)

    def gradientDescent_bgd2(self, x, y, alpha, epoch):
        self.theta = np.zeros((x.shape[1], 1))
        for i in range(epoch):
            sum_gradient = np.zeros(self.theta.shape)
            for index in range(len(x)):
                y_hat = np.dot(x[index:index+1], self.theta)
                sum_gradient += np.dot(x[index:index+1].T, (y_hat - y[index]))
            self.theta -= alpha * (1/y.size) * sum_gradient
            c = self.cost(x, y)
            self.costs.append(c)

    def gradientDescent_sgd(self, x, y, alpha, epoch):
        self.theta = np.zeros((x.shape[1], 1))
        for i in range(epoch):
            for index in range(len(x)):
                y_hat = np.dot(x[index:index + 1], self.theta)
                self.theta -= alpha * (1 / y.size) * (np.dot(x[index:index + 1].T, (y_hat - y[index])))
                c = self.cost(x, y)
                self.costs.append(c)

    def gradientDescent_mbgd(self, x, y, alpha, epoch, batch_size):
        self.theta = np.zeros((x.shape[1], 1))
        for i in range(epoch):
            for j in range(0, len(x), batch_size):
                sum_gradient = np.zeros(self.theta.shape)
                for k in range(batch_size):
                    index = j+k
                    y_hat = np.dot(x[index:index+1], self.theta)
                    sum_gradient += (np.dot(x[index:index + 1].T, (y_hat - y[index])))
                self.theta -= alpha * (1 / y.size) * sum_gradient
                c = self.cost(x, y)
                self.costs.append(c)

    def cost(self, x, y):
        y_hat = np.dot(x, self.theta)
        c = (1/(2 * y.size)) * np.square(y_hat - y).sum()
        return c

    def fsolve(self, x, y):
        return np.dot(np.dot(np.linalg.inv(np.dot(x.T, x)), x.T), y)

    def r2_score(self, x, y):
        y_hat = np.dot(x, self.theta)
        return r2_score(y, y_hat)


if __name__ == "__main__":
    # X1 = np.array([25, 28, 31, 35, 38, 40]).reshape((-1,1))
    # X = np.column_stack((np.ones((X1.shape[0], 1)), X1))
    # Y = np.array([106, 145, 167, 208, 233, 258]).reshape((-1,1))
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478.,
         484.,
         489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
         14285., 18254.,
         21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
    X1 = np.array(x).reshape((-1, 1))
    X = np.column_stack((np.ones((X1.shape[0], 1)), X1))
    Y = np.array(y).reshape((-1,1))
    linear = Linear()
    # 解析解
    print("解析解：", linear.fsolve(X, Y))  # [[-134.06243902],[9.75317073]]

    # 批量梯度下降1
    # linear.gradientDescent_bgd(X, Y, alpha=0.001, epoch=500000)
    # print(linear.theta) # [[-134.06208818],[9.75316032]]

    # 批量梯度下降2
    linear.gradientDescent_bgd2(X, Y, alpha=0.000001, epoch=500000)
    print(linear.theta)  #[[-134.06208818],[9.75316032]]
    print(linear.r2_score(X, Y))

    # sgd
    # linear.gradientDescent_sgd(X, Y, alpha=0.001, epoch=500000)
    # print(linear.theta) # [[-134.32769465], [9.76204092]]

    # mbgd
    # linear.gradientDescent_mbgd(X, Y, alpha=0.001, epoch=500000, batch_size=3)
    # print(linear.theta) # [[-133.5445137 ],  [9.73404222]]
    #
    # c = linear.costs[1:]
    # x_coor = range(len(c))
    # print("x_coor: ", x_coor)
    # plt.plot(x_coor, c)
    # plt.show()





