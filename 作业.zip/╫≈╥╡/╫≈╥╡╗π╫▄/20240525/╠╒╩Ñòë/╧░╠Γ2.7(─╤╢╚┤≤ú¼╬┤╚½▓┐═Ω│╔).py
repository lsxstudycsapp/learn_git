
# 数据呈现抛物线，应使用多项式扩展，加一个x^2
# 多项式扩展没做出来
# 思路混乱了
class Linear:
    def __init__(self, intercept=True):
        self.intercept = True
        self.theta_0 = 0
        self.theta = None
        self.costs = []

    def bgd(self, x, y, alpha, epoch, ):
        num_theta = len(x[0])
        # 初始化权重和截距参数
        self.theta = [0 for i in range(num_theta)]
        coe_gradient = [0 for i in range(num_theta)]
        theta_0_gradient = 0
        # 开始训练
        for i in range(epoch):
            for x_true, y_true in zip(x, y):
                # 基于2个特征的参数计算每个样本的预测值
                sum_y_hat = 0
                for a, b in zip(x_true, coe_gradient):
                    sum_y_hat += (a * b)
                y_hat = sum_y_hat + self.theta_0

                # 分别求得2个特征的权重参数的梯度值
                coe_gradient[0] += (1 / len(y)) * (y_hat - y_true) * x_true[0]
                coe_gradient[1] += (1 / len(y)) * (y_hat - y_true) * x_true[1]

                # 截距的梯度值
                theta_0_gradient += (1 / len(y)) * (y_hat - y_true)

            # 更新权重参数
            self.theta[0] -= alpha * coe_gradient[0]
            self.theta[1] -= alpha * coe_gradient[1]
            self.theta_0 -= alpha * theta_0_gradient

            # 计算损失
            c = self.cost(x, y)
            self.costs.append(c)

    def cost(self, x, y):
        c = 0
        for x_true, y_true in zip(x, y):
            sum_y_hat = 0
            for a, b in zip(x_true, self.theta):
                sum_y_hat += (a * b)
            y_hat = sum_y_hat + self.theta_0
            # print(y_hat - y_true)
            # 这里出错了
            c += (1 / (2 * len(y))) * ((y_hat - y_true)**2)
        return c

    def r2_score(self):
        pass


def polynomial_features(x, degree, interception = False):
    # interception = False的情况
    l = []
    for i in x:
        l.append([i ** j for j in range(1, degree + 1)])
    return l


if __name__ == '__main__':
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478.,
         484.,
         489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
         14285., 18254.,
         21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

    # 数据预处理
    x_poly = polynomial_features(x, degree=2)
    print(x_poly)

    # 构建模型
    lm = Linear()
    lm.bgd(x_poly, y, alpha=0.000000000001, epoch=1000)
    print(lm.theta)
    print(lm.theta_0)
