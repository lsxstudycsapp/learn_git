import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score


mpl.rcParams['font.sans-serif'] = [u'simHei']
mpl.rcParams['axes.unicode_minus'] = False

X_org = np.array([
    [10, 1],
    [15, 1],
    [20, 1],
    [30, 1],
    [50, 2],
    [60, 1],
    [60, 2],
    [70, 2]]).reshape((-1, 2))
Y = np.array([0.8, 1.0, 1.8, 2.0, 3.2, 3.0, 3.1, 3.5]).reshape((-1, 1))

X = np.column_stack((np.ones((X_org.shape[0], 1)), X_org))

theta = np.dot(np.dot(np.linalg.inv(np.dot(X.T, X)), X.T), Y)

print(theta)

x_test = np.array([[1.0, 55.0, 2.0]])
y_test_pred = np.dot(x_test, theta)
print(y_test_pred) # [[3.07059925]]


