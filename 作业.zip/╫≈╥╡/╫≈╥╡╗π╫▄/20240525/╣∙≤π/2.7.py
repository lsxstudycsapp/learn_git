import time

x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469, 478., 484.,
     489, 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269, 4109, 6077, 7502., 10094., 11534.,
     14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

# 定义模型参数
a = 0
b = 0

# 定义超参数
lr = 0.000001  # 学习率
epochs = 100000  # 训练轮数


# 定义损失函数和优化器
def mse_loss(y_true, y_pred):
    return ((y_true - y_pred) ** 2).mean()


def gradient_descent(x, y, a, b, lr, epochs):
    start_time = time.time()
    for epoch in range(epochs):
        y_pred = a * x + b
        loss = mse_loss(y, y_pred)
        if epoch % 10000 == 0:
            print('epoch:', epoch, 'loss:', loss)
        a_gradient = -(2 * (y - y_pred) * x).mean()
        b_gradient = -(2 * (y - y_pred)).mean()
        a -= lr * a_gradient
        b -= lr * b_gradient
    end_time = time.time()
    return a, b, end_time - start_time


# 训练模型
a, b, training_time = gradient_descent(x, y, a, b, lr, epochs)

# 计算训练集的r2_score
y_pred = a * x + b
ssr = ((y_pred - y.mean()) ** 2).sum()
sst = ((y - y.mean()) ** 2).sum()
r2_score = ssr / sst

# 打印结果
print('模型参数：a={:.4f}, b={:.4f}'.format(a, b))
print('训练集的r2_score:', r2_score)
print('模型训练时间（毫秒）:', training_time * 1000)
