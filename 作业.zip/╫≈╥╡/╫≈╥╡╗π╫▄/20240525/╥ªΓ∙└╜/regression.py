import matplotlib.pyplot as plt
import time

x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445.,
     450., 458., 462., 469., 478., 484., 489., 495., 496., 502., 509., 511., 514.,
     516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109.,
     6077, 7502., 10094., 11534., 14285., 18254., 21170., 23765., 27077., 27650.,
     31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]


# # 画散点图
# plt.scatter(x, y)
# plt.show()   # 图形像抛物线，故采用二次项回归模型

# 定义模型 y = k(x+a)^2 + b
def model(x, k, a, b):
    return k * (x + a) ** 2 + b


# 定义损失函数
def cost(x, y, k, a, b):
    m = len(x)
    loss = 0
    for i in range(m):
        y_pred = model(x[i], k, a, b)
        loss += (y[i] - y_pred) ** 2
    return loss / m


# 计算 r2_score
def r2_score(y, y_pred):
    mean_y = sum(y) / len(y)
    ss_total = sum((yi - mean_y) ** 2 for yi in y)
    ss_residual = sum((yi - yi_pred) ** 2 for yi, yi_pred in zip(y, y_pred))
    return 1 - (ss_residual / ss_total)


# 定义梯度
def gradient(x, y, k, a, b):
    m = len(x)
    dk = da = db = 0
    for i in range(m):
        y_pred = model(x[i], k, a, b)
        dk += -(y[i] - y_pred) * (x[i] + a) ** 2
        da += -(y[i] - y_pred) * 2 * k * (x[i] + a)
        db += -(y[i] - y_pred)
    dk /= m
    da /= m
    db /= m
    return dk, da, db


# 梯度下降算法
def gradient_descent(x, y, k, a, b, alpha, iter):
    costs = []
    start_time = time.time()
    for i in range(iter):
        dk, da, db = gradient(x, y, k, a, b)
        k -= alpha * dk
        a -= alpha * da
        b -= alpha * db
        c = cost(x, y, k, a, b)
        costs.append(c)
    end_time = time.time()
    training_time = (end_time - start_time) * 1000  # 记录时间，单位为毫秒
    return k, a, b, costs, training_time


if __name__ == '__main__':
    k, a, b, costs, t = gradient_descent(x, y, 0, 0, 0, 0.0000000001, 800000)
    y_pred = [model(xi, k, a, b) for xi in x]
    r2 = r2_score(y, y_pred)
    print(f'k={k}, a={a}, b={b}')        # k=3.00052102540318, a=-400.00723905104525, b=-0.023172086739719294
    print(f'r2_score={r2}')              # r2_score=0.9999999712892945
    print(f'training_time = {t:.2f}ms')  # 34146.45ms
    print("cost=", costs[-1])            # cost= 6.703421629120174

    # # 画损失函数变化图
    # costs = costs[100000:]
    # cc = range(len(costs))
    # plt.plot(cc, costs)
    # plt.show()

    # # 画散点图和拟合的直线
    # plt.scatter(x, y)
    # plt.plot(x, y_pred, color='red')
    # plt.show()
