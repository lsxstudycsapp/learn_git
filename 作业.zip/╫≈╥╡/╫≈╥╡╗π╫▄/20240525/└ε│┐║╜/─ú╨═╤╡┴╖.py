import time
import matplotlib.pyplot as plt

# 计算模型预测值
def predict(x, b0, b1, b2):
    return b0 + b1 * x + b2 * x**2

# 计算损失值（均方误差）
def compute_loss(x, y, b0, b1, b2):
    N = len(x)
    return sum((y_i - predict(x_i, b0, b1, b2))**2 for x_i, y_i in zip(x, y)) / N

# 计算损失函数的梯度
def compute_gradients(x, y, b0, b1, b2):
    N = len(x)
    b0_gradient = (-2/N) * sum(y_i - predict(x_i, b0, b1, b2) for x_i, y_i in zip(x, y))
    b1_gradient = (-2/N) * sum((y_i - predict(x_i, b0, b1, b2)) * x_i for x_i, y_i in zip(x, y))
    b2_gradient = (-2/N) * sum((y_i - predict(x_i, b0, b1, b2)) * x_i**2 for x_i, y_i in zip(x, y))
    return b0_gradient, b1_gradient, b2_gradient

# 更新模型参数
def update_parameters(b0, b1, b2, learning_rate, b0_gradient, b1_gradient, b2_gradient):
    new_b0 = b0 - learning_rate * b0_gradient
    new_b1 = b1 - learning_rate * b1_gradient
    new_b2 = b2 - learning_rate * b2_gradient
    return new_b0, new_b1, new_b2

# 计算均值
def mean(values):
    return sum(values) / float(len(values))

# 计算R²分数
def r_squared(y_true, y_pred):
    mean_y_true = mean(y_true)
    ss_res = sum((y_true[i] - y_pred[i])**2 for i in range(len(y_true)))
    ss_tot = sum((y_true[i] - mean_y_true)**2 for i in range(len(y_true)))
    return 1 - (ss_res / ss_tot)

# 标准化数据
def standardize(data):
    mean_val = mean(data)
    std_dev = (sum((x - mean_val)**2 for x in data) / len(data))**0.5
    return [(x - mean_val) / std_dev for x in data], mean_val, std_dev

# 逆标准化
def destandardize(data, mean_val, std_dev):
    return [x * std_dev + mean_val for x in data]

# 训练模型
def quadratic_regression_with_gradient_descent(x_train, y_train, learning_rate, max_iterations=400, tolerance=1e-5):
    start_time = time.time()
    # 初始化参数
    b0, b1, b2 = 0, 0, 0
    # 迭代优化
    for iteration in range(max_iterations):
        # 计算梯度
        b0_gradient, b1_gradient, b2_gradient = compute_gradients(x_train, y_train, b0, b1, b2)
        # 更新参数
        new_b0, new_b1, new_b2 = update_parameters(b0, b1, b2, learning_rate, b0_gradient, b1_gradient, b2_gradient)
        # 计算当前损失值
        loss = compute_loss(x_train, y_train, new_b0, new_b1, new_b2)
        # 输出当前迭代次数和损失值
        print(f"Iteration {iteration + 1}: Loss = {loss}")
        # 检查收敛
        if abs(b0 - new_b0) < tolerance and abs(b1 - new_b1) < tolerance and abs(b2 - new_b2) < tolerance:
            break
        # 更新参数
        b0, b1, b2 = new_b0, new_b1, new_b2
    end_time = time.time()
    return b0, b1, b2, (end_time - start_time) * 1000

# 训练数据
x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

# 标准化数据
x_standardized, x_mean, x_std = standardize(x)
y_standardized, y_mean, y_std = standardize(y)

# 设置学习率
learning_rate = 0.25

# 训练模型
b0, b1, b2, training_time = quadratic_regression_with_gradient_descent(x_standardized, y_standardized, learning_rate)

# 计算训练集R²分数
y_pred_standardized = [predict(x_i, b0, b1, b2) for x_i in x_standardized]
y_pred = destandardize(y_pred_standardized, y_mean, y_std)
r2_score = r_squared(y, y_pred)

print("模型参数:")
print("b0:", b0)
print("b1:", b1)
print("b2:", b2)
print("训练集的R²分数:", r2_score)
print("模型训练时间(毫秒):", training_time)

# 可视化原始数据和拟合曲线
plt.scatter(x, y, color='blue', label='Data Points')
plt.plot(x, y_pred, color='red', label='Fitted Curve')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()
