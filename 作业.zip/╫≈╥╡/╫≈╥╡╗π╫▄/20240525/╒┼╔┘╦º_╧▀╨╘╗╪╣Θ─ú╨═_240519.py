import time

import matplotlib
import matplotlib.pyplot as plt


# 点乘
def dot_products(a, b):
    result = [[0 for j in range(len(b[0]))] for i in range(len(a))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                result[i][j] += a[i][k] * b[k][j]
    return result


# 转置
def transpose_matrix(matrix):
    return [list(row) for row in zip(*matrix)]


# 减法
def sub_matrix(matrix1, matrix2):
    return [[a - b for a, b in zip(row1, row2)] for row1, row2 in zip(matrix1, matrix2)]


# 乘法
def mult_matrix(matrix, scalar):
    return [[element * scalar for element in row] for row in matrix]


# 矩阵的逆
def inverse_matrix(matrix):
    n = len(matrix)
    identity_matrix = [[float(i == j) for i in range(n)] for j in range(n)]

    for i in range(n):
        if matrix[i][i] == 0:
            for j in range(i + 1, n):
                if matrix[j][i] != 0:
                    matrix[i], matrix[j] = matrix[j], matrix[i]
                    identity_matrix[i], identity_matrix[j] = identity_matrix[j], identity_matrix[i]
                    break
            else:
                return None

        pivot = matrix[i][i]
        for j in range(i, n):
            matrix[i][j] /= pivot
        for j in range(n):
            identity_matrix[i][j] /= pivot

        for j in range(i + 1, n):
            factor = matrix[j][i]
            for k in range(i, n):
                matrix[j][k] -= factor * matrix[i][k]
            for k in range(n):
                identity_matrix[j][k] -= factor * identity_matrix[i][k]

    for i in range(n - 1, 0, -1):
        for j in range(i):
            factor = matrix[j][i]
            for k in range(i, n):
                matrix[j][k] -= factor * matrix[i][k]
            for k in range(n):
                identity_matrix[j][k] -= factor * identity_matrix[i][k]

    return identity_matrix


# 计算矩阵的和
def multi_dim_sum(arr):
    total = 0
    for item in arr:
        if isinstance(item, list):
            total += multi_dim_sum(item)
        else:
            total += item
    return total


# 训练时间计时
def time_log(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"{func.__name__}运行时间：{elapsed_time}秒")
        return result

    return wrapper


# min-max特征归一化
class MinMaxScaler:
    def fit_transform(self, x):
        X = []
        x_max = max(x)
        x_min = min(x)
        for i in range(len(x)):
            x_norm = (x[i] - x_min) / (x_max - x_min)
            X.append(x_norm)
        return X


# 多项式扩展
class PolynomialFeatures:
    """
    degree：阶数
    interaction_only：是否只含交叉项（本项目该参数无意义）
    include_bias：是否包含偏置项
    """

    def __init__(self, degree, interaction_only=False, include_bias=False):
        self.degree = degree
        self.interaction_only = interaction_only
        self.include_bias = include_bias
        self.result = None

    def fit(self, X):
        if self.include_bias:
            self.result = [[1, i, i ** self.degree] for i in X]
        else:
            self.result = [[i, i ** self.degree] for i in X]


class LinearRegression:
    def __init__(self, X_poly, Y_poly, method='bgd'):
        self.X_poly = X_poly
        self.Y_poly = Y_poly
        self.method = method
        self.theta = [[1], [1], [1]]
        self.score = 0

    def fit(self, alpha=0.01, iters=60000):
        if self.method == 'bgd':
            self.bgd(alpha, iters)
        elif self.method == 'sgd':
            self.sgd(alpha, iters)
        elif self.method == 'fsolve':
            self.fsolve()

    @time_log
    def bgd(self, alpha, iters):
        m = len(self.Y_poly)
        y_hat = []
        for i in range(iters):
            y_hat = dot_products(self.X_poly, self.theta)
            gradient = dot_products(transpose_matrix(self.X_poly), sub_matrix(y_hat, self.Y_poly))
            self.theta = sub_matrix(self.theta, mult_matrix(gradient, alpha / m))

        self.r2(y_hat)

    @time_log
    def sgd(self, alpha, iters):
        m = len(self.Y_poly)
        y_hat = []
        for i in range(iters):
            y_hat = []
            for index in range(len(X)):
                y_predict = dot_products(self.X_poly[index:index + 1], self.theta)
                gradient = dot_products(transpose_matrix(self.X_poly[index:index + 1]),
                                        sub_matrix(y_predict, self.Y_poly[index:index + 1]))
                self.theta = sub_matrix(self.theta, mult_matrix(gradient, alpha / m))
                y_hat.extend(y_predict)
        self.r2(y_hat)

    @time_log
    def fsolve(self):
        inverse = inverse_matrix(dot_products(transpose_matrix(self.X_poly), self.X_poly))
        self.theta = dot_products(dot_products(inverse, transpose_matrix(self.X_poly)), self.Y_poly)
        y_hat = dot_products(self.X_poly, self.theta)
        self.r2(y_hat)

    def r2(self, y_hat):
        avg_Y = multi_dim_sum(self.Y_poly) / len(self.Y_poly)
        rss = sum((self.Y_poly[i][0] - y_hat[i][0]) ** 2 for i in range(len(self.Y_poly)))
        tss = sum((ele[0] - avg_Y) ** 2 for ele in self.Y_poly)
        self.score = 1 - (rss / tss)


if __name__ == "__main__":
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478.,
         484.,
         489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534.,
         14285., 18254., 21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
    # X，Y的数据归一化
    scaler = MinMaxScaler()
    X = scaler.fit_transform(x)
    Y = scaler.fit_transform(y)

    poly = PolynomialFeatures(2, True, True)
    poly.fit(X)
    # X的多项式扩展
    X_poly = poly.result
    Y_poly = [[y] for y in Y]
    theta = [[1], [1], [1]]

    # linear = LinearRegression(X_poly, Y_poly, method='bgd')
    # linear = LinearRegression(X_poly, Y_poly, method='sgd')
    linear = LinearRegression(X_poly, Y_poly, method='fsolve')
    linear.fit(alpha=0.1, iters=100000)
    print(f'theta值为：{linear.theta}')
    print(f'r2值为：{linear.score}')
    # bgd的theta：   [[0.7994570974105367], [-3.393802965899014], [3.594345868474235]]
    # sgd的theta：   [[0.7994570974125546], [-3.3938029659087676], [3.5943458684832543]]
    # fsolve的theta：[[0.7994570974576088], [-3.393802966101625], [3.5943458686440035]]

    X_poly_plt = [row[1] for row in X_poly]
    Y_poly_plt = [row[0] for row in Y_poly]
    Y_poly_predict = dot_products(X_poly, linear.theta)
    Y_poly_predict_plt = [row[0] for row in Y_poly_predict]
    plt.scatter(X_poly_plt, Y_poly_plt, color='red', label='actual')
    plt.plot(X_poly_plt, Y_poly_predict_plt, color='blue', label='predict')
    plt.show()
