"""
有以下数据：
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
   请训练一个线性回归模型，要求训练集的r2_score在0.999以上。提交的内容包括：模型参数，训练集的r2_score，以及模型训练的时间(毫秒)。
   可选语言：Python或者c++。
   如果用Python语言，不能使用numpy和pandas，不能使用sklearn。如果用c++，只能用原生的c++语言，不能调用任何矩阵运算库和机器学习库。
"""

import time
start_time = time.time()


class LinearRegression:
    # 针对此问题, 该线性回归类只解决X具有一个特征的数据
    def __init__(self, intercept=True):
        self.theta = None
        self.theta0 = 0
        self.intercept = intercept

    def gradient_descent(self, X, y, alpha, iters):
        # 初始化theta
        if self.intercept:
            X = [[1] + sublist for sublist in X]
        theta = [0 for _ in range(len(X[0]))]

        m = len(y)
        n = len(X[0])
        y_hat = [0 for _ in range(m)]
        for it in range(iters):
            # 计算y_hat
            for i in range(m):
                y_item = 0
                for j in range(n):
                    y_item += X[i][j] * theta[j]
                y_hat[i] = y_item

            # 更新theta值
            for i in range(n):
                aver_sum_gra = 0
                for j in range(m):
                    aver_sum_gra += X[j][i] * (y_hat[j] - y[j])
                theta[i] -= alpha * (1.0 / m) * aver_sum_gra

        if self.intercept:
            self.theta = theta[1:]
            self.theta0 = theta[0]
        else:
            self.theta = theta
            self.theta0 = 0

    # 训练模型fit函数
    def fit(self, X, y, alpha=0.1, iters=500000):
        self.gradient_descent(X, y, alpha, iters)

    # 使用模型predict函数
    def predict(self, X):
        # 初始化theta
        if self.intercept:
            theta = [self.theta0] + self.theta
            X = [[1] + sublist for sublist in X]
        else:
            theta = self.theta
        m = len(X)
        # 计算y_hat
        y_hat = [0 for _ in range(m)]
        for i in range(m):
            y_item = 0
            for j in range(len(theta)):
                y_item += X[i][j] * theta[j]
            y_hat[i] = y_item
        return y_hat

    # fit_transform函数
    def fit_transform(self, X, y, alpha=0.1, iters=500000):
        self.fit(X, y, alpha, iters)
        return self.predict(X)

    def score(self, X, y):
        y_hat = self.predict(X)
        y_aver = sum(y) / len(y)
        rss = 0
        tss = 0
        for i in range(len(y)):
            rss += (y_hat[i] - y[i]) ** 2
            tss += (y_hat[i] - y_aver) ** 2

        # R2
        r2 = 1 - rss / tss
        return r2


class PolynomialFeatures:
    """
        多项式拓展:针对此问题, 只解决X具有一个特征的数据
    """
    def __init__(self, degree, include_bias=True):
        self.degree = degree
        self.include_bias = include_bias

    # 定义fit函数, 多项式拓展的fit是确认哪些新增指标, 这里return self, 这些参数确定新增指标
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        length = len(X)
        # 初始化poly_features二维列表
        if self.include_bias:
            poly_features = [[1]*(self.degree + 1) for _ in range(length)]
        else:
            poly_features = [[1] * self.degree for _ in range(length)]

        # 将x, x^2填充到poly_features
        for index, item in enumerate(X):
            poly_features[index][-2] = item
            poly_features[index][-1] = item ** 2

        return poly_features

    def fit_transform(self, X, y=None):
        self.fit(X, y)
        return self.transform(X)


def standardize(data, include_bias=True):
    if include_bias:
        bias = 1
    else:
        bias = 0

    m, n = len(data), len(data[0])  # 获取数据的形状（行数m和列数n）
    # 初始化均值和标准差列表
    means = [0.0] * n
    stds = [1.0] * n  # 初始化为1，稍后会被真实标准差覆盖，避免除以零

    # 计算每列的均值
    for j in range(bias, n):
        column_sum = 0.0
        for i in range(m):
            column_sum += data[i][j]
        means[j] = column_sum / m

    # 计算每列的标准差
    for j in range(bias, n):
        column_variance = 0.0
        for i in range(m):
            deviation = data[i][j] - means[j]
            column_variance += deviation ** 2
        stds[j] = (column_variance / m) ** 0.5
        if stds[j] == 0:  # 避免除以零，设置一个很小的值代替
            stds[j] = 1e-7

    # 标准化数据
    standardized_data = [[1] * n for _ in range(m)]  # 初始化标准化后的数据矩阵
    for i in range(m):
        for j in range(bias, n):
            standardized_data[i][j] = (data[i][j] - means[j]) / stds[j]

    return standardized_data, means, stds


x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
poly = PolynomialFeatures(2, include_bias=False)
x_train_poly = poly.fit_transform(x)

x_train_sta, means, stds = standardize(x_train_poly, include_bias=False)
print("means = ", means)
print("stds = ", stds)
# print(x_train_sta)

linear = LinearRegression(intercept=True)
y_predict = linear.fit_transform(x_train_sta, y, alpha=1, iters=5000)
print("theta = ", linear.theta)
print("theta0 = ",linear.theta0)
r2 = linear.score(x_train_sta, y)
print("R2 = ", r2)

# 记录结束时间
end_time = time.time()

# 计算耗时
elapsed_time = end_time - start_time
print(f"程序耗时: {elapsed_time*1000:.6f} ms")
