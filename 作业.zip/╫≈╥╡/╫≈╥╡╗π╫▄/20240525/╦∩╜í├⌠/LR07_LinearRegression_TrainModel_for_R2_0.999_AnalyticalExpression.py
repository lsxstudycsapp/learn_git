"""
有以下数据：
    x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
    y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]
   请训练一个线性回归模型，要求训练集的r2_score在0.999以上。提交的内容包括：模型参数，训练集的r2_score，以及模型训练的时间(毫秒)。
   可选语言：Python或者c++。
   如果用Python语言，不能使用numpy和pandas，不能使用sklearn。如果用c++，只能用原生的c++语言，不能调用任何矩阵运算库和机器学习库。
"""

import time
start_time = time.time()


def inv(A):
    """
    Gauss_Jordan elimination method

    Args:
        A: n * n 维矩阵

    Returns:
        A 的逆矩阵
    """
    n = len(A)
    if n == 0:
        raise ValueError("Matrix must be non-empty")

    # 构造增广矩阵 [A | I]
    A_inv = [row[:] + [0] * n for row in A]
    for j in range(n):
        A_inv[j][j + n] = 1

    for i in range(n):
        # 将主元变为1
        pivot = A_inv[i][i]
        for j in range(n * 2):
            A_inv[i][j] /= pivot

        # 将下面的行消成0
        for k in range(i + 1, n):
            factor = A_inv[k][i]
            for j in range(n * 2):
                A_inv[k][j] -= factor * A_inv[i][j]

        # 将上面的行消成0
        for k in range(i):
            factor = A_inv[k][i]
            for j in range(n * 2):
                A_inv[k][j] -= factor * A_inv[i][j]

    # 此时A_inv的左半部分为单位矩阵，右半部分为A的逆
    return [A_inv[i][n:] for i in range(n)]

def mat_mult(A, B):
    """
    Implementing matrix multiplication.

    Args:
        A: m x n 矩阵
        B: n x p 矩阵

    Returns:

    """
    m, n = len(A), len(A[0])  # 获取 A 的行数和列数
    assert n == len(B), "矩阵 A 的列数必须等于矩阵 B 的行数"
    p = len(B[0])  # 矩阵 B 的列数，即结果矩阵的列数

    # 初始化矩阵 C 为 m x p 的零矩阵
    C = [[0 for _ in range(p)] for _ in range(m)]

    # 执行矩阵乘法
    for i in range(m):
        for j in range(p):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]

    return C

def mat_t(A):
    """
    求矩阵的转置矩阵
    Args:
        A: m * n 矩阵

    Returns:
        A 的转置矩阵
    """

    # 获取矩阵的行数和列数
    rows = len(A)
    if rows == 0:
        return []
    cols = len(A[0])

    # 初始化转置后的矩阵
    transposed = [[0 for _ in range(rows)] for _ in range(cols)]

    # 遍历原始矩阵的每一个元素，并将其放置到转置矩阵的正确位置
    for i in range(rows):
        for j in range(cols):
            transposed[j][i] = A[i][j]

    return transposed


def score(X, Y, theta):
    y_hat = mat_mult(X ,theta)
    y = [item for lst in Y for item in lst]
    y_hat = [item for lst in Y for item in lst]
    y_aver = sum(y) / len(y)
    rss = 0
    tss = 0
    for i in range(len(y)):
        rss += (y_hat[i] - y[i]) ** 2
        tss += (y_hat[i] - y_aver) ** 2

    # R2
    r2 = 1 - rss / tss
    return r2

class PolynomialFeatures:
    """
    多项式拓展:针对此问题, 只解决X具有一个特征的数据
    """
    def __init__(self, degree, include_bias=True):
        self.degree = degree
        self.include_bias = include_bias

    # 定义fit函数, 多项式拓展的fit是确认哪些新增指标, 这里return self, 这些参数确定新增指标
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        length = len(X)
        # 初始化poly_features二维列表
        if self.include_bias:
            poly_features = [[1]*(self.degree + 1) for _ in range(length)]
        else:
            poly_features = [[1] * self.degree for _ in range(length)]

        # 将x, x^2填充到poly_features
        for index, item in enumerate(X):
            poly_features[index][-2] = item
            poly_features[index][-1] = item ** 2

        return poly_features

    def fit_transform(self, X, y=None):
        self.fit(X, y)
        return self.transform(X)


# 初始数据集
x = [290., 329., 342., 359., 369., 386., 395., 410., 425., 427., 433., 437., 445., 450., 458., 462., 469., 478., 484.,
     489., 495., 496., 502., 509., 511., 514., 516., 518., 521., 523.]
y = [36302., 15125., 10094., 5045., 2885., 590., 77., 302., 1877., 2189., 3269., 4109., 6077, 7502., 10094., 11534., 14285., 18254.,
     21170., 23765., 27077., 27650., 31214., 35645., 36965., 38990., 40370., 41774., 43925., 45389.]

# 特征工程：数据集进行多项式拓展
poly = PolynomialFeatures(2)
x_train_poly = poly.fit_transform(x)
# print(x_train_poly)

# 嵌套列表
X = x_train_poly
Y = [[i] for i in y]

# 训练模型
# 采用解析表达式theta = (X.T*X).I*X.T*Y求解
theta = mat_mult(mat_mult(inv(mat_mult(mat_t(X),X)), mat_t(X)), Y)
print("theta = ", theta[1:])
print("theta0 = ",theta[0])

# 模型评估
r2 = score(X, Y, theta)
print(" R^2 = ",r2)

# 记录结束时间
end_time = time.time()
# 计算耗时
elapsed_time = end_time - start_time
print(f"程序耗时: {elapsed_time*1000:.10f} ms")