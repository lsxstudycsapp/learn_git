#pragma once

extern const int len;

class LinearRegression
{
public:
	LinearRegression();
	//LinearRegression(const LinearRegression& linear_mdel);
	//~LinearRegression();

	double* getTheta() const;
	double getR2_score() const;

public:
	double* gradient_descent_bgd(double ** x_t, double * y_t, double * theta, double alpha, int max_tier);
	double* y_predict(double ** x_set, const int x_len) const;
	double costs(double ** x_t, double * y_t) const;
	void R2_score(double** x_t, double* y_t);

private:
	double * theta;
	double r2_score;
};
