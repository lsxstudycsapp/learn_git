#include "LinearRegression.h"
#include <iostream>

LinearRegression::LinearRegression() 
	: theta(nullptr), r2_score(-1.0) {}

//LinearRegression::LinearRegression(const LinearRegression& linear_mdel)
//{
//	this->r2_score = linear_mdel.getR2_score();
//	if (this->theta != nullptr)
//	{
//		delete[] this->theta;
//		this->theta = nullptr;
//	}
//	this->theta = linear_mdel.getTheta();
//}
//
//LinearRegression::~LinearRegression()
//{
//	if (this->theta != nullptr)
//	{
//		delete[] this->theta;
//		this->theta = nullptr;
//	}
//}

double* LinearRegression::getTheta() const
{
	return this->theta;
}

double LinearRegression::getR2_score() const
{
	return this->r2_score;
}

// �����ݶ��½������ض���ָ�룬�ǵ��ͷţ�
double* LinearRegression::gradient_descent_bgd(double** x_t, double* y_t, double* theta, double alpha, int max_tier)
{
	double* cost_lst = new double[max_tier];
	this->theta = theta;
	double a = 1.0 / (2 * len) * alpha;
	double y_hat;

	for (int i = 0; i < max_tier; ++i)
	{
		double gradient_sum0 = 0.0, gradient_sum1 = 0.0, gradient_sum2 = 0.0;
		for (int j = 0; j < len; ++j)
		{
			y_hat = x_t[j][0] * this->theta[0] + x_t[j][1] * this->theta[1] + x_t[j][2] * this->theta[2];
			gradient_sum0 += (y_hat - y_t[j]) * x_t[j][0];
			gradient_sum1 += (y_hat - y_t[j]) * x_t[j][1];
			gradient_sum2 += (y_hat - y_t[j]) * x_t[j][2];
		}
		// �����ݶ�
		this->theta[0] -= a * gradient_sum0;
		this->theta[1] -= a * gradient_sum1;
		this->theta[2] -= a * gradient_sum2;
		// ������ʧ
		cost_lst[i] = this->costs(x_t, y_t);
	}
	return cost_lst;
}

// ��Ԥ��ֵ(���ض���ָ�룬�ǵ��ͷ�)
double* LinearRegression::y_predict(double** x_set, const int x_len) const
{
	double * y_pred = new double[x_len];
	double y_hat;
	for (int i = 0; i < x_len; ++i)
	{
		y_hat = x_set[i][0] * this->theta[0] + x_set[i][1] * this->theta[1] + x_set[i][2] * this->theta[2];
		y_pred[i] = y_hat;
	}
	return y_pred;
}

// ������ʧ
double LinearRegression::costs(double** x_t, double* y_t) const
{
	double y_hat, cost = 0.0;
	for (int i = 0; i < len; ++i)
	{
		y_hat = x_t[i][0] * this->theta[0] + x_t[i][1] * this->theta[1] + x_t[i][2] * this->theta[2];
		cost += (y_hat - y_t[i]) * (y_hat - y_t[i]);
	}
	cost = 1.0 / (2 * len) * cost;
	return cost;
}

// R2_score����
void LinearRegression::R2_score(double** x_t, double* y_t)
{
	double rss = 0.0, tss = 0.0;
	double y_sum = 0.0;
	for (int i = 0; i < len; ++i)
	{
		y_sum += y_t[i];
	}
	// y_t ��ƽ��ֵ
	double y_mean = y_sum / len;

	double y_hat;
	for (int i = 0; i < len; ++i)
	{
		y_hat = x_t[i][0] * this->theta[0] + x_t[i][1] * this->theta[1] + x_t[i][2] * this->theta[2];
		rss += (y_t[i] - y_hat)* (y_t[i] - y_hat);
		tss += (y_t[i] - y_mean) * (y_t[i] - y_mean);
	}
	this->r2_score = 1 - rss / tss;
	return;
}



