#include "train.h"

int main()
{
	train();
    system("pause");
	return 0;
}