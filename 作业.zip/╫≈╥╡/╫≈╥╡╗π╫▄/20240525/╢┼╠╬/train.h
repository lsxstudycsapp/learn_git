#pragma once
#include <iostream>
#include "LinearRegression.h"
#include <opencv2/opencv.hpp> // ������ͼ

void train();

double* minMaxValue(double* array);
double** polynomial(double* array);
void minMax(double** x_data, double* y_data);
void draw(double** x, double* y, double* y_hat_lst, double* cost_lst, int max_iter);